#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#define MAX(a,b) ((a)>(b))?(a):(b)
struct Treenode{
    int data;
    struct Treenode* parent;
    struct Treenode* right;
    struct Treenode* left;
};
struct BT{
    struct Treenode* ROOT;
};
struct Treenode* CREATE_NODE(int k){
    struct Treenode* node=(struct Treenode*)malloc(1*sizeof(struct Treenode));
    node->data=k;
    node->left=NULL;
    node->right=NULL;
    node->parent=NULL;
    return node;
}
struct Treenode* MAKEBST(int arr[],int s,int e){
    if(s>e){
        return NULL;
    }
    int mid=(s+e)/2;
    struct Treenode* root=CREATE_NODE(arr[mid]);
    struct Treenode* l=MAKEBST(arr,s,mid-1);
    struct Treenode* r=MAKEBST(arr,mid+1,e);
    root->left=l;
    root->right=r;
    if(l!=NULL){
        l->parent=root;
    }
    if(r!=NULL){
        r->parent=root;
    }
    return root;
}
int EvaluateHeight(struct Treenode* root){
    if(root==NULL){
        return 0;
    }
    return MAX(EvaluateHeight(root->left),EvaluateHeight(root->right))+1;
}
void PrintTree(struct Treenode* root){
    if(root==NULL){
        printf("( ) ");
        return;
    }
    printf("( ");
    printf("%d ",root->data);
    PrintTree(root->left);
    PrintTree(root->right);
    printf(") ");
    return;
}
void EvaluateSumOfLEVEL(struct Treenode* root,long long arr[],int layer){
  if(root==NULL){
    return;
  }
    arr[layer]=arr[layer]+root->data;
    EvaluateSumOfLEVEL(root->left,arr,layer+1);
    EvaluateSumOfLEVEL(root->right,arr,layer+1);
    return;
}
int main() {
    int n;
    scanf("%d",&n);
    int arr[n];
    for(int i = 0;i<n;i++){
      scanf("%d",&arr[i]);
    }
    struct Treenode* ROOT=MAKEBST(arr,0,n-1);
    PrintTree(ROOT);
    printf("\n");
    int layers=0;
    layers=EvaluateHeight(ROOT);
    long long LVL[layers];
    for(int i=0;i<layers;i++){
      LVL[i]=0;
    }
    EvaluateSumOfLEVEL(ROOT,LVL,0);
    for(int i=0;i<layers;i++){
      printf("%lld ",LVL[i]);
    }
    printf("\n");
    return 0;
}

