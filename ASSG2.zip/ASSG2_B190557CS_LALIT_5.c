#include<stdio.h>
#include<stdlib.h>
#include<string.h>
struct Treenode{
    int data;
    struct Treenode* right;
    struct Treenode* left;
};
struct BST{
    struct Treenode* ROOT;
};
struct Treenode* CREATE_NODE(int k){
    struct Treenode* node=(struct Treenode*)calloc(1,sizeof(struct Treenode));
    node->data=k;
    node->left=NULL;
    node->right=NULL;
    return node;
}
struct Treenode* MinNode(struct Treenode* Root){
    if(Root==NULL){
        return NULL;
    }
    if(Root->left!=NULL){
        return MinNode(Root->left);
    }
    return Root;
}
struct Treenode* MaxNode(struct Treenode* Root){
    if(Root==NULL){
        return NULL;
    }
    if(Root->right!=NULL){
        return MaxNode(Root->right);
    }
    return Root;
}
struct Treenode* SEARCH(struct Treenode* root,int k){
        if(root==NULL){
            return NULL;
        }
        if(root->data==k){
            return root;
        }
        if(root->data>k){
            struct Treenode* x=SEARCH(root->left,k);
            return x;
        }
        if(root->data<k){
            struct Treenode* x=SEARCH(root->right,k);
            return x;
        }
    return NULL;
}
int FindTreeEnd(int s,int e,char arr[]){
    if (s>e){
        return -1;
    }
    int total=0;
    for(int i=s;i<=e;i++){
       if(arr[i]== '('){
            total=total+1;
        }else if(arr[i]==')'){
            total=total-1;
            if(total==0){
                return i;
            }
        }
    }
    return -1;
}
struct Treenode* BUILD(int s,int e,char arr[]){
    if(s>e||arr[s+2]==')'){
        return NULL;
    }
    int K=0,indx=-1,NumEndIndx=-1;
    for(int i=s+2;arr[i]!=' ';i++){
        K=K*10+(arr[i]-48);
        NumEndIndx=i;
    }
    struct Treenode* root=CREATE_NODE(K);
    if (NumEndIndx+2<=e&&arr[NumEndIndx+2] =='('){
        indx=FindTreeEnd(NumEndIndx+2,e,arr);
    }
    if(indx!=-1){
        root->left=BUILD(NumEndIndx+2,indx,arr);
        root->right=BUILD(indx+2,e-1,arr);
    }
    return root;
}
struct Treenode* KSMALLHELPER(struct Treenode* root,int* k){
    if (root == NULL){
        return NULL;
    }
    struct Treenode* l=KSMALLHELPER(root->left,k);
    if(l!=NULL){
        return l;
    }
    (*k)=(*k)-1;
    if((*k)==0){
        return root;
    }
    return KSMALLHELPER(root->right,k);
}
int KSMALLEST(struct Treenode* Root,int kth){
    struct Treenode* k=KSMALLHELPER(Root,&kth);
    if(k==NULL){
        return -1;
    }else{
        return k->data;
    }
}
struct Treenode* KLARGESTHELPER(struct Treenode* root,int* k){
    if (root == NULL){
        return NULL;
    }
    struct Treenode* r=KLARGESTHELPER(root->right,k);
    if(r!=NULL){
        return r;
    }
    (*k)=(*k)-1;
    if((*k)==0){
        return root;
    }
    return KLARGESTHELPER(root->left,k);
}
int KLARGEST(struct Treenode* Root,int kth){
    struct Treenode* k=KLARGESTHELPER(Root,&kth);
    if(k==NULL){
        return -1;
    }else{
        return k->data;
    }
}
struct Treenode* PREDECESSOR(struct Treenode* root,int K){
    if(root==NULL){
        return NULL;
    }
    struct Treenode* p= NULL;
    struct Treenode* current= root;
    while(current!=NULL&&current->data!=K){
        if(current->data<=K){
             p=current;
             current = current->right;
        }else{
            current=current->left;
        }
    }
    if(current!=NULL&&current->left!=NULL){
        p=MaxNode(current->left);
    }
    return p;
}
struct Treenode* SUCCESSOR(struct Treenode* root,int K){
    if(root==NULL){
        return NULL;
    }
    struct Treenode* s= NULL;
    struct Treenode* current= root;
    while(current!=NULL&&current->data!=K){
        if(current->data>=K){
             s=current;
             current = current->left;
        }else{
            current=current->right;
        }
    }
    if(current!=NULL&&current->right!=NULL){
        s=MinNode(current->right);
    }
    return s;
}
void INORDERHELPER(struct Treenode* T){
    if(T==NULL){
        return;
    }else{
        INORDERHELPER(T->left);
        printf("%d ",T->data);
        INORDERHELPER(T->right);
    }
}
void INORDER(struct BST* T){
    INORDERHELPER(T->ROOT);
    printf("\n");
    return;
}
int main(){
    char arr[1000000];
    scanf("%[^\n]%*c",arr);
    int kth;
    scanf("%d",&kth);
    int n=(int)strlen(arr);
    struct Treenode* Root=BUILD(0,n-1,arr);
    struct BST* T=(struct BST*)calloc(1,sizeof(struct BST));
    T->ROOT=Root;
    char c;
    scanf("%c",&c);
    while(c!='e'){
       if(c=='r'){
            int k;
            scanf("%d",&k);
            struct Treenode* temp=SEARCH(T->ROOT,k);
           if(temp==NULL){
               printf("-1\n");
           }else{
               struct Treenode* x=PREDECESSOR(T->ROOT,k);
               if(x!=NULL){
                   printf("%d\n",x->data);
               }else{
                   printf("-1\n");
               }
           }
        }else if(c=='u'){
            int k;
            scanf("%d",&k);
            struct Treenode* temp=SEARCH(T->ROOT,k);
           if(temp==NULL){
               printf("-1\n");
           }else{
            struct Treenode* x=SUCCESSOR(T->ROOT,k);
            if(x!=NULL){
                printf("%d\n",x->data);
            }else{
                printf("-1\n");
            }
           }
        }else if(c=='i'){
            INORDER(T);
        }else if(c=='l'){
            int k;
            scanf("%d",&k);
            printf("%d\n",KLARGEST(T->ROOT,k));
        }else if(c=='s'){
            int k;
            scanf("%d",&k);
            printf("%d\n",KSMALLEST(T->ROOT,k));
        }
        scanf("%c",&c);
    }
    return 0;
}



