#include <stdio.h>
#include <string.h>
#include <stdlib.h>
struct node{
    char* word;
    struct node* next;
};
int SpecialPowerValue_Hashcode(int power[8],char* word){
    int arr[8]={0};
    int sum=0;
    for(int i=0;word[i];i++){
        int indx=word[i]-97;
        if(arr[indx]==0){
            sum+=power[indx];
            arr[indx]=1;
        }
    }
    return sum;
}
void Sort_LEXI(struct node* Node){
    int size=0;
    struct node* temp=Node;
    while(temp!=NULL){
        size++;
        temp=temp->next;
    }
    if(size==1){
        return;
    }
   for(int i=0;i<size-1;i++){
        struct node* temp=Node;
        for (int j=0;j<size-i-1; j++){
            struct node* nxt=temp->next;
            if(strcmp(temp->word,nxt->word)>0){
                char *tmp=(char*)malloc((1000000)*sizeof(char));
                strcpy(tmp,temp->word);
                strcpy(temp->word,nxt->word);
                strcpy(nxt->word,tmp);
            }
            temp=temp->next;
        }
    }
    return;
}
struct node* Createnode(char* Word){
    struct node* N=(struct node*)calloc(1,sizeof(struct node));
    N->word=Word;
    N->next=NULL;
    return N;
}
void INSERT(struct node** arr,char* Word,int* power){
    int indx=SpecialPowerValue_Hashcode(power,Word);
    struct node* K=Createnode(Word);
    if(arr[indx]==NULL){
        arr[indx]=K;
        return;
    }
    struct node* temp=arr[indx];
    while(temp->next!=NULL){
        temp=temp->next;
    }
    temp->next=K;
    return ;
}
void Print(struct node** arr,int size){
    for(int i=0;i<size;i++){
        struct node* temp=arr[i];
        if(arr[i]==NULL){
            continue;
        }
        while(temp!=NULL){
            if(temp->next!=NULL){
                printf("%s",temp->word);
                printf(" ");
            }else{
                printf("%s\n",temp->word);
            }
            temp=temp->next;
        }
    }
    return;
}
int main(){
    int m;
    scanf("%d",&m);
    int power[8]={0};
    power[0]=1;
    for(int i=1;i<8;i++){
        power[i]=2*power[i-1];
    }
    struct node** arr=(struct node**)calloc(256,sizeof(struct node*));
    for(int i=0;i<m;i++){
        arr[i]=NULL;
    }
    for(int i=0;i<m;i++){
        char *word=(char*)malloc((1000000)*sizeof(char));
        scanf("%s",word);
        INSERT(arr,word,power);
    }
    for(int i=0;i<256;i++){
        if(arr[i]!=NULL){
            Sort_LEXI(arr[i]);
        }
    }
    Print(arr,256);
    return 0;
}


