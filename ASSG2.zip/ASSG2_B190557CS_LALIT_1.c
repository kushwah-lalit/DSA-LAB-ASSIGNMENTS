#include <stdio.h>
#include <stdlib.h>
struct HASHTABLE{
    int* arr;
    char x;
    int m,a,b,r;
    int index;
};
int *HASHTABLE(int S){
    int* arr=(int*)calloc(1,S);
    for(int i=0;i<S;i++){
        arr[i]=-1;
    }
    return arr;
}
int evaluate_r(int m){
    int isPrime[m+1];
    for(int i=0;i<m;i++){
        isPrime[i]=0;
    }
    isPrime[0] = 1;
    isPrime[1] = 1;
     for(int i=2;i*i<=m;i++){
         if(isPrime[i] == 0){
             for(int j=i*i;j<=m;j+=i){
                    isPrime[j] = 1;
             }
         }
     }
    for(int i=m-1;i>=1;i--){
        if(isPrime[i]==0){
            return i;
        }
    }
    return -1;
}
int H1(int k,int m){
    return (k%m+m)%m;
}
int H2(int k,int r){
    return r-((k%r+r)%r);
}
int Double_Hashing(int i,int k,int m,int r){
    return H1(((H2(k,r)*i)%m+m)%m+H1(k,m),m);
}
int Quad_Hashing(int i,int k,int m,int a,int b){
    a=H1(a,m);
    b=H1(b,m);
    int temp=((((a%m)*i)%m+((((b%m)*i)%m)*i)%m)%m);
    return (H1(k,m)+temp)%m;
}
void INSERT(struct HASHTABLE* T,int k){
    T->arr[T->index]=k;
    return;
}
void DELETE(struct HASHTABLE* T,int k){
    T->arr[T->index]=-1;
    return;
}
int SEARCH(struct HASHTABLE* T,int k){
    if(T->x=='a'){
        int indx=-1;
        for(int i=0;i<T->m;i++){
            indx=Quad_Hashing(i,k,T->m,T->a,T->b);
            if(T->arr[indx]==k){
                return indx;
            }
        }
    }else if(T->x=='b'){
        int indx=-1;
        for(int i=0;i<T->m;i++){
            indx=Double_Hashing(i,k,T->m,T->r);
            if(T->arr[indx]==k){
                return indx;
            }
        }
    }
    return -1;
}
void PRINT(struct HASHTABLE* T){
    for(int i=0;i<T->m;i++){
        if(T->arr[i]==-1){
            printf("%d ()\n",i);
        }else{
            printf("%d (%d)\n",i,T->arr[i]);
        }
    }
}
int main(){
    char c;
    scanf("%c",&c);
    int M,A=1,B=1,R;
    scanf("%d",&M);
    int* array=HASHTABLE(M);
    struct HASHTABLE* T=(struct HASHTABLE*)calloc(1,sizeof(struct HASHTABLE));
    if(c=='a'){
        scanf("%d %d",&A,&B);
    }
    R=evaluate_r(M);
    T->arr=array;
    T->m=M;
    T->x=c;
    T->a=A;
    T->b=B;
    T->r=R;
    char k;
    scanf("%c",&k);
    while(k!='t'){
        if(k=='i'){
            int key;
            scanf("%d",&key);
            if(c=='a'){
                for(int i=0;;i++){
                    int indx=Quad_Hashing(i,key,T->m,T->a,T->b);
                    if(T->arr[indx]==-1){
                        T->index=indx;
                        INSERT(T,key);
                        break;
                    }
                }
            }else if(c=='b'){
                for(int i=0;;i++){
                    int indx=Double_Hashing(i,key,T->m,T->r);
                    if(T->arr[indx]==-1){
                        T->index=indx;
                        INSERT(T,key);
                        break;
                    }
                }
            }
        }else if(k=='s'){
            int key;
            scanf("%d",&key);
            int indx=SEARCH(T,key);
            if(indx==-1){
                printf("-1\n");
            }else{
                printf("1\n");
            }
        }else if(k=='d'){
            int key;
            scanf("%d",&key);
            int indx=SEARCH(T,key);
            if(indx!=-1){
                T->index=indx;
                DELETE(T,key);
            }
        }else if(k=='p'){
            PRINT(T);
        }
        scanf("%c",&k);
    }
    return 0;
}

