#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#define MAX(a,b) ((a)>(b))?(a):(b)
struct Treenode{
    int data;
    struct Treenode* right;
    struct Treenode* left;
};
struct BT{
    struct Treenode* ROOT;
};
struct Treenode* CREATE_NODE(int k){
    struct Treenode* node=(struct Treenode*)malloc(1*sizeof(struct Treenode));
    node->data=k;
    node->left=NULL;
    node->right=NULL;
    return node;
}
struct Treenode* INSERT(struct Treenode* root,int k){
        if(root==NULL){
            struct Treenode* c=CREATE_NODE(k);
            return c;
        }
        if(root->data>k){
            struct Treenode* l=INSERT(root->left,k);
            root->left=l;
            return root;
        }else if(root->data<k){
            struct Treenode* r=INSERT(root->right,k);
            root->right=r;
            return root;
        }
    return NULL;
}
int MAXVALUE(struct Treenode* Root,int k){
    int max=-2147483648;
    while(Root->data!=k){
        if(Root->data>max){
            max=Root->data;
        }
        if(Root->data<k){
            Root=Root->right;
        }else if(Root->data>k){
            Root=Root->left;
        }
    }
    return max;
}
struct Treenode* EvaluateLCA(struct Treenode* root, int a,int b){
    if(root==NULL){
        return NULL;
    }
    if(root->data==a||root->data==b){
        return root;
    }
    struct Treenode* l=EvaluateLCA(root->left,a,b);
    struct Treenode* r=EvaluateLCA(root->right,a,b);
    if(l==NULL&&r==NULL){
        return NULL;
    }else if(l==NULL){
            return r;
    }else if(r==NULL){
            return l;
    }else{
        return root;
    }
}
int ISNUM(char c){
    if(c>='0'&&c<='9'){
        return 1;
    }else{
        return 0;
    }
}
int main(){
    char X[1000000];
    scanf("%[^\n]%*c",X);
    int arr[1000000]={0};
    int n=0;
    for(int i=0;X[i];i++){
        if(X[i]==' '){
            continue;
        }else if(ISNUM(X[i])==1){
            int num=0;
            while(ISNUM(X[i])!=0){
            num=num*10+(int)(X[i]-48);
            i++;
            }
            i--;
            arr[n++]=num;
        }
    }
    int a,b;
    scanf("%d%d",&a,&b);
    struct BT* T=(struct BT*)calloc(1,sizeof(struct BT));
    T->ROOT=NULL;
    for(int i=0;i<n;i++){
        T->ROOT=INSERT(T->ROOT,arr[i]);
    }
    printf("%d\n",MAXVALUE(EvaluateLCA(T->ROOT,a,b),MAX(a,b)));
    return 0;
}


