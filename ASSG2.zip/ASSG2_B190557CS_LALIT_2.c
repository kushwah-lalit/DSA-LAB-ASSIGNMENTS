#include <stdio.h>
#include <string.h>
#include <stdlib.h>
struct node{
    char* word;
    struct node* next;
};
int Hash(char* word,int size){
    int k=(int)strlen(word);
    k=k%size;
    return (k*k)%size;
}
struct node* Createnode(char* Word){
    struct node* N=(struct node*)calloc(1,sizeof(struct node));
    N->word=Word;
    N->next=NULL;
    return N;
}
void INSERT(struct node** arr,char* Word,int size){
    int indx=Hash(Word,size);
    struct node* K=Createnode(Word);
    if(arr[indx]==NULL){
        arr[indx]=K;
        return;
    }
    struct node* temp=arr[indx];
    while(temp->next!=NULL){
        if(strcmp(temp->word,Word)==0){
            return;
        }else{
            temp=temp->next;
        }
    }
    if(strcmp(temp->word,Word)==0){
        return;
    }
    temp->next=K;
    return ;
}
void Print(struct node** arr,int size){
    for(int i=0;i<size;i++){
        struct node* temp=arr[i];
        if(arr[i]==NULL){
            printf("%d:%s\n",i,"null");
            continue;
        }
        printf("%d:",i);
        while(temp!=NULL){
            if(temp->next!=NULL){
                printf("%s",temp->word);
                printf("-");
            }else{
                printf("%s\n",temp->word);
            }
            temp=temp->next;
        }
    }
    return;
}
int main(){
    int m;
    char string[1000];
    scanf("%d %[^\n]%*c",&m,string);
    struct node** arr=(struct node**)calloc(m,sizeof(struct node*));\
    for(int i=0;i<m;i++){
        arr[i]=NULL;
    }
    int size=(int)strlen(string);
    for(int i=0;i<size;){
        int j=i;
        while(string[j]!=' '){
            j++;
        }
        j=j-1;
        int indx=0;
        char *word=(char*)malloc((1000)*sizeof(char));
        for(int k=i;k<=j;k++){
            word[indx++]=string[k];
        }
        word[indx]='\0';
        INSERT(arr,word,m);
        i=j+2;
    }
    Print(arr,m);
    return 0;
}

