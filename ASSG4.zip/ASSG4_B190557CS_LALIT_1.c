#include <stdio.h>
#include <string.h>
#include <stdlib.h>
struct ConnectionNode{
    int vertex;
    struct ConnectionNode* next;
};
struct ConnectionNode* Createnode(int V){
    struct ConnectionNode* N=(struct ConnectionNode*)calloc(1,sizeof(struct ConnectionNode));
    N->vertex=V;
    N->next=NULL;
    return N;
}
void INSERT(struct ConnectionNode** arr,int V,int indx){
    struct ConnectionNode* K=Createnode(V);
    if(arr[indx]==NULL){
        arr[indx]=K;
        return;
    }
    struct ConnectionNode* temp=arr[indx];
    while(temp->next!=NULL){
        temp=temp->next;
    }
    temp->next=K;
    return;
}
void Print(struct ConnectionNode** arr,int size){
    for(int i=0;i<size;i++){
        struct ConnectionNode* temp=arr[i];
        printf("%d ",i);
        if(arr[i]==NULL){
            printf("\n");
            continue;
        }
        while(temp!=NULL){
            if(temp->next!=NULL){
                printf("%d ",temp->vertex);
            }else{
                printf("%d\n",temp->vertex);
            }
            temp=temp->next;
        }
    }
    return;
}
int main(){
    int m;
    scanf("%d",&m);
    struct ConnectionNode** AdjList=(struct ConnectionNode**)calloc(m,sizeof(struct ConnectionNode*));
    for(int i=0;i<m;i++){
        AdjList[i]=NULL;
    }
    int** AdjMat=(int**)malloc(m*sizeof(int*));
    for(int i=0;i<m;i++){
        AdjMat[i]=(int*)calloc(m,sizeof(int));
        for(int j=0;j<m;j++){
            scanf("%d",&AdjMat[i][j]);
        }
    }
    for(int i=0;i<m;i++){
        for(int j=0;j<m;j++){
            if(AdjMat[i][j]==1){
                INSERT(AdjList,j,i);
            }
        }
    }
    Print(AdjList,m);
    return 0;
}


