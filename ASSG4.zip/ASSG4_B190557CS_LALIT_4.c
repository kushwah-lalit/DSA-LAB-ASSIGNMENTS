#include <stdio.h>
#include <string.h>
#include <stdlib.h>
//queue
struct node{
    int data;
    struct node* nxt;
};
struct QUEUE{
    struct node* head;
    struct node* tail;
};
struct QUEUE* BuildQueue(){
    struct QUEUE* Q=(struct QUEUE*)calloc(1,sizeof(struct QUEUE));
    Q->head=NULL;
    Q->tail=NULL;
    return Q;
}
struct node* CREATE_NODE(int k){
     struct node* x=(struct node*)malloc(1*sizeof(struct node));
     x->data=k;
     x->nxt=NULL;
     return x;
 }
int QueueEmpty(struct QUEUE* Q){
    if(Q->head==NULL){
        return 0;
    }
    return 1;
}
void Enqueue(struct QUEUE* Q,int x){
    struct node* X=CREATE_NODE(x);
    if(Q->head==NULL){
        Q->head=X;
        Q->tail=X;
    }else{
        Q->tail->nxt=X;
        Q->tail=X;
    }
    return;
}
int Dequeue(struct QUEUE* Q){
    if(Q->head==NULL) {
        return -1;
    }
    struct node *x=Q->head;
    Q->head=Q->head->nxt;
    x->nxt=NULL;
    int k=x->data;
    free(x);
    return k;
}
//queue code ends
struct ConnectionNode{
    int vertex;
//    int distance;
//    struct ConnectionNode* NxtV;
//    int color;
    // white 0 grey 1 black 2
    struct ConnectionNode* next;
};
struct ConnectionNode* Createnode(int V){
    struct ConnectionNode* N=(struct ConnectionNode*)calloc(1,sizeof(struct ConnectionNode));
    N->vertex=V;
    N->next=NULL;
//    N->distance=2147483647;
//    N->NxtV=NULL;
//    N->color=0;
    return N;
}
void INSERT(struct ConnectionNode** arr,int V,int indx){
    struct ConnectionNode* K=Createnode(V);
    if(arr[indx]==NULL){
        arr[indx]=K;
        return;
    }
    struct ConnectionNode* temp=arr[indx];
    while(temp->next!=NULL){
        if(temp->vertex==V){
            return;
        }
        temp=temp->next;
    }
    if(temp->vertex==V){
        return;
    }
    temp->next=K;
    return;
}
void Print(struct ConnectionNode** arr,int size){
    for(int i=0;i<size;i++){
        struct ConnectionNode* temp=arr[i];
        printf("%d ",i);
        if(arr[i]==NULL){
            printf("\n");
            continue;
        }
        while(temp!=NULL){
            if(temp->next!=NULL){
                printf("%d ",temp->vertex);
            }else{
                printf("%d\n",temp->vertex);
            }
            temp=temp->next;
        }
    }
    return;
}
void BFS(struct ConnectionNode** arr,int s,int m){
    int Distance[m];
    int Color[m];
    int NxtV[m];
    // white 0 grey 1 black 2
    for(int i=0;i<m;i++){
        Distance[i]=2147483647;
        Color[i]=0;
        NxtV[i]=-1;
    }
    Distance[s]=0;
    Color[s]=1;
    NxtV[s]=-1;
    struct QUEUE* Q=BuildQueue();
    Enqueue(Q,s);
    int u=s;
    while(QueueEmpty(Q)!=0){
        u=Dequeue(Q);
        struct ConnectionNode* v=arr[u];
        while(v!=NULL){
            if(Color[v->vertex]==0){
                Color[v->vertex]=1;
                Distance[v->vertex]=Distance[u]+1;
                NxtV[v->vertex]=u;
                Enqueue(Q,v->vertex);
            }
            v=v->next;
        }
        printf("%d ",u);
        Color[u]=2;
    }
    printf("\n");
    return;
}
void DFS(struct ConnectionNode** arr,int s,int* Color){
    printf("%d ",s);
    Color[s]=1;
    struct ConnectionNode* v=arr[s];
    while(v!=NULL){
        if(Color[v->vertex]==0){
            DFS(arr,v->vertex,Color);
        }
        v=v->next;
    }
    return;
}
int main(){
    int m;
    scanf("%d",&m);
    int e;
    scanf("%d",&e);
    struct ConnectionNode** AdjList=(struct ConnectionNode**)calloc(m,sizeof(struct ConnectionNode*));
    for(int i=0;i<m;i++){
        AdjList[i]=NULL;
    }
    for(int i=0;i<e;i++){
        int a,b;
        scanf("%d %d",&a,&b);
        INSERT(AdjList,b,a);
    }
    int s;
    scanf("%d",&s);
    BFS(AdjList,s,m);
    int Color[m];
    for(int i=0;i<m;i++){
        Color[i]=0;
        //white 0 black 1
    }
    DFS(AdjList,s,Color);
    printf("\n");
    return 0;
}



