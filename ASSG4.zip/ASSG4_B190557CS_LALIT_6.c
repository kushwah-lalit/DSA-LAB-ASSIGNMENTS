#include <stdio.h>
#include <stdlib.h>
#include <math.h>
struct node{
  int key;
  struct node *child;
  struct node *parent;
  int mark;
  int deg;
  struct node *next;
  struct node *prev;
};
struct dll{
  int size;
  struct node *head;
  struct node *tail;
};
struct fibheap{
  struct dll *a;
  struct node *min;
  int n;
};
void fibheaplink(struct fibheap *H,struct node *y,struct  node *x);
void consolidate(struct fibheap *H);
struct node *extract_min(struct fibheap *H);
void cut(struct fibheap *H,struct node *x,struct node *y);
void cascadingcut(struct fibheap *H,struct node *y);
struct node* decrease_key(struct fibheap *H,struct node *x,int k);
struct node *hash[1000];
struct dll *create_dll(){
  struct dll *y=(struct dll *)calloc(1,sizeof(struct dll));
    y->size = 0;
    y->head = NULL;
    y->tail = NULL;
    return y;
}
struct fibheap *makeheap(){
  struct fibheap *H=(struct fibheap *)calloc(1,sizeof(struct fibheap));
  H->a =(struct dll *)calloc(1,sizeof(struct dll));
  H->min = NULL;
  H->a = create_dll();
  H->n = 0;
  return H;
}
struct node *create_node(int k){
   struct node *y=(struct node *)calloc(1,sizeof(struct node));
    y->key = k;
    y->child = NULL;
    y->parent = NULL;
    y->deg = 0;
    y->mark = 0;
    y->next = y;
    y->prev = y;
    return y;
}
struct dll *insert_front(struct dll *dl, struct node *x){
  if (dl->head != NULL){
      x->next = dl->head;
      dl->head->prev = x;
      dl->head = x;
  }else{
      dl->head = x;
      dl->tail = x;
  }
  dl->size+=1;
  return dl;
}
struct dll *insert_end(struct dll *dl, struct node *x){
  if (dl->head!= NULL){
      x->prev = dl->tail;
      dl->tail->next = x;
      dl->tail = x;
  }else{
      dl->head = x;
      dl->tail = x;
  }
  dl->size+=1;
  return dl;
}
void insert(struct fibheap *H, struct node *x){
    if(!H->min){
    H->min=x;
    return;
    }
//    inserting x
    struct node* k=H->min->prev;
    k->next=x;
    x->prev=k;
    x->next=H->min;
    H->min->prev=x;
    if(H->min->key>x->key){
      H->min = x;
    }
    hash[x->key]=x;
    H->n+=1;
    return;
}
void fibheaplink(struct fibheap *H, struct node *y, struct node *x){
    struct node* Yprevious=y->prev;
    Yprevious->next=y->next;
    y->next->prev=Yprevious;
    if (x->next==x){
    H->min=x;
    }
    y->prev = y;
    y->next = y;
    y->parent = x;
    if (!x->child){
    x->child=y;
    }
    struct node* xChild=x->child;
    y->next = xChild;
    y->prev = xChild->prev;
    struct node* xChildPrevious=xChild->prev;
    xChildPrevious->next = y;
    xChildPrevious = y;
    if(x->child->key>y->key){
    x->child = y;
    }
    x->deg=x->deg+1;
    return;
}
void consolidate(struct fibheap *H){
    float s=log2(H->n);
    int size=s,x;
    size+=1;
    struct node *A[size];
    struct node *y=H->min,*z,*y1,*z1=H->min;
    for(int i = 0; i<= size; i++){
    A[i] = NULL;
    }
    
    do{
    z1=z1->next;
    x=y->deg;
    while(A[x]!=NULL){
      z = A[x];
      if(z->key<y->key){
        y1 = y;
        y = z;
        z = y1;
      }
      if(z==H->min){
        H->min = y;
      }
      fibheaplink(H, z, y);
      if(y==y->next){
        H->min = y;
      }
      A[x] = NULL;
      x+=1;
    }
    A[x] = y;
    y = y->next;
    }while(y!= H->min);
    
    H->min = NULL;
    
    int j=0;
    while(j<size){
        if(A[j]!=NULL){
//            pointing itself
            A[j]->next = A[j];
            A[j]->prev = A[j];
          if (H->min!=NULL){
              struct node* HMinPrev=H->min->prev;
              HMinPrev->next = A[j];
              A[j]->next = H->min;
              A[j]->prev = HMinPrev;
              HMinPrev= A[j];
                if(A[j]->key<H->min->key){
                  H->min = A[j];
                }
          }else{
            H->min = A[j];
              if(A[j]->key<H->min->key){
                H->min = A[j];
              }
          }
        }
        j+=1;
    }
}
struct node *extract_min(struct fibheap *H){
    if(H->min==NULL){
        return NULL;
    }else{
        struct node*x=NULL;
        struct node*y=H->min;
        struct node*z=y;
        if(y->child!=NULL){
           x=y->child;
           do{
            struct node* HMinPrev=H->min->prev;
            z =x->next;
            HMinPrev->next =x;
            x->next =H->min;
            x->prev =HMinPrev;
            HMinPrev=x;
            if (x->key<H->min->key){
              H->min = x;
            }
            x->parent = NULL;
            x = z;
           }while(z!= y->child);

        }
        struct node* yPrev=y->prev;
        struct node* yNxt=y->next;
        yPrev->next=yNxt;
        yNxt->prev=yPrev;
        H->min=yNxt;
        if(y==y->next && y->child==NULL){
          H->min = NULL;
        }else{
          H->min = y->next;
          consolidate(H);
        }
        H->n-=1;
        return y;
    }
}
void cut(struct fibheap *H,struct node *x,struct node *y){
     if (x==x->next){
        y->child = NULL;
     }
    struct node* xPrev=x->prev,*xNxt=x->next;
    xPrev->next = xNxt;
    xNxt->prev = xPrev;
    if(x==y->child){
        y->child =x->next;
    }
    x->next=x;
    x->prev=x;
    y->deg-=1;
    struct node* HMinPrev=H->min->prev;
    HMinPrev->next=x;
    x->next=H->min;
    x->prev=HMinPrev;
    HMinPrev=x;
    x->parent = NULL;
    x->mark=0;
    return;
}
void cascadingcut(struct fibheap *H,struct node *y){
    struct node *z=y->parent;
    if(z){
     if(y->mark==0){
       y->mark=1;
     }else{
       cut(H,y,z);
       cascadingcut(H,z);
     }
    }
    return;
}
struct node* decrease_key(struct fibheap *H,struct node *x,int k){
    struct node *y = x->parent;
    if(x->key<k){
        return NULL;
    }
    x->key=k;
    if(y){
        if(x->key<y->key){
            cut(H,x,y);
            cascadingcut(H,y);
        }
    }
    if(H->min->key>x->key){
      H->min=x;
    }
    return x;
}
void del(struct fibheap *H,struct node *x){
    decrease_key(H,x,-1000000);
    extract_min(H);
}
void print_dll(struct dll *h){
  printf("%d ",h->head->key);
  struct node *y= h->head->next;
  while(y->key!=h->head->key){
    printf("%d ",y->key);
    y=y->next;
  }
  printf("\n");
}
int main(){
  struct fibheap *H = makeheap();
  char ch;
  scanf("%c", &ch);
  while(ch!='e'){
      if(ch=='i'){
          int k;
          scanf("%d", &k);
          struct node *x=create_node(k);
          insert(H, x);
      }else if(ch=='x'){
          struct node* x=extract_min(H);
          if(x!=NULL){
            printf("%d\n",x->key);
          }
      }else if(ch=='m'){
          printf("%d\n",H->min->key);
      }else if(ch=='r'){
          int k1,k2;
          scanf("%d %d",&k1,&k2);
          H->a->head=H->min;
          struct node *x=hash[k1];
          if(x!=NULL){
            printf("%d\n",decrease_key(H,x,k2)->key);
          }
      }else if(ch=='p'){
          H->a->head = H->min;
          print_dll(H->a);
      }else if(ch=='d'){
          int k;
          scanf("%d",&k);
          struct node *x = hash[k];
          if(x!=NULL){
            printf("%d\n",x->key);
          }
          del(H,x);
      }
      scanf("%c", &ch);
  }
    return 0;
}
