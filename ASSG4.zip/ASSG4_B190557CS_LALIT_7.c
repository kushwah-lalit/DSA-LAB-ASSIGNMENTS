#include <stdio.h>
#include <stdlib.h>
struct set{
    int DSType;
    int Parent[10001];
    int Rank[10001];
};
struct set* BuildDS(int type){
    struct set* Dset=(struct set*)malloc(1*sizeof(struct set));
    Dset->DSType=type;
    for(int i=0;i<10001;i++){
        Dset->Parent[i]=-1;
    }
    return Dset;
}
struct set* MAKESET(int x,struct set* S){
    if(S->Parent[x]!=-1){
        if(S->DSType==0){
            printf("-1\n");
        }
        return S;
    }
    if(S->DSType==0){
        printf("%d\n",x);
    }
    S->Parent[x]=x;
    S->Rank[x]=0;
    return S;
}
int Find(int x,struct set* S,int* Count){
    Count[S->DSType]+=1;
    if(S->Parent[x]==-1){
        return -1;
    }
    if(S->DSType==2||S->DSType==3){
        if(S->Parent[x]==x){
            return x;
        }else{
            return S->Parent[x]=Find(S->Parent[x],S,Count);
        }
   }else{
       if(S->Parent[x]==x){
           return x;
       }else{
           return Find(S->Parent[x],S,Count);
       }
    }
}
struct set* Union(int x,int y,struct set* S,int* Count){
    int ParentX=S->Parent[x];
    int ParentY=S->Parent[y];
    if(ParentX==-1||ParentY==-1){
        printf("-1 ");
        return S;
    }
    ParentX=Find(x,S,Count);
    ParentY=Find(y,S,Count);
    if(S->DSType==1||S->DSType==3){
        if(S->Rank[ParentX]>S->Rank[ParentY]){
            S->Parent[ParentY]=ParentX;
            printf("%d ",ParentX);
        }else if(S->Rank[ParentX]<S->Rank[ParentY]){
            S->Parent[ParentX]=ParentY;
            printf("%d ",ParentY);
        }else{
            S->Parent[ParentY]=ParentX;
            S->Rank[ParentX]+=1;
            printf("%d ",ParentX);
        }
        return S;
    }else{
        S->Parent[ParentY]=ParentX;
        printf("%d ",ParentX);
        return S;
    }
}
int main(){
    struct set** Dsets=(struct set**)malloc(4*sizeof(struct set*));
    int* CallCount=(int*)malloc(4*sizeof(int));
    for(int i=0;i<4;i++){
        CallCount[i]=0;
        Dsets[i]=BuildDS(i);
    }
    char c;
    scanf("%c",&c);
    while(1){
        if(c=='m'){
            int x;
            scanf("%d",&x);
            for(int i=0;i<4;i++){
                Dsets[i]=MAKESET(x,Dsets[i]);
            }
        }else if(c=='f'){
            int x;
            scanf("%d",&x);
            for(int i=0;i<4;i++){
                int k=Find(x,Dsets[i],CallCount);
                if(k==-1){
                    printf("-1 ");
                }else{
                    printf("%d ",k);
                }
            }
            printf("\n");
        }else if(c=='u'){
            int x,y;
            scanf("%d %d",&x,&y);
            for(int i=0;i<4;i++){
                Dsets[i]=Union(x,y,Dsets[i],CallCount);
            }
            printf("\n");
        }else if(c=='s'){
            printf("%d %d %d %d",CallCount[0],CallCount[1],CallCount[2],CallCount[3]);
            printf("\n");
            return 0;
        }
        scanf("%c",&c);
    }
}
//m 1
//m 2
//m 3
//m 4
//m 5
//m 6
//m 7
//m 8
//m 9
//u 1 2
//u 3 4
//u 5 6
//u 7 8
//u 9 8
//u 6 8
//u 4 8
//u 2 8
//f 9
//m 10
//u 10 9
//s

