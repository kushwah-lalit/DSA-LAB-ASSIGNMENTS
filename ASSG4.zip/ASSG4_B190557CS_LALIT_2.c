#include<stdio.h>
#include<stdlib.h>
struct ConnectionNode{
    int vertex;
    int EdgeWeight;
    struct ConnectionNode* next;
};
struct ConnectionNode* CreateNode(int k){
    struct ConnectionNode* X=(struct ConnectionNode*)calloc(1,sizeof(struct ConnectionNode));
    X->vertex=k;
    X->next=NULL;
    X->EdgeWeight=0;
    return X;
}
void InputEdgeWeights(struct ConnectionNode** arr,int v){
    for(int i=0;i<v;i++){
        struct ConnectionNode* tmp=arr[i];
        while(tmp!=NULL){
            int w;
            scanf("%d",&w);
            tmp->EdgeWeight=w;
            tmp=tmp->next;
        }
    }
    return;
}
void InputAdjList(struct ConnectionNode** arr,int v){
    for(int i=0;i<v;i++){
        struct ConnectionNode* temp=arr[i];
        int firstinput=0;
        char checktermination=' ';
        while(checktermination!='\n'){
            int adjacent;
            scanf("%d",&adjacent);
            if(firstinput==0){
                firstinput=-1;
                arr[i]=CreateNode(adjacent);
                temp=arr[i];
            }else{
                temp->next=CreateNode(adjacent);
                temp=temp->next;
            }
            scanf("%c",&checktermination);
        }
    }
    InputEdgeWeights(arr,v);
    return;
}
int MinWeightVertex(int* weight,int* vertexVisited,int v){
    int min=2147483647,minV=-1;
        for(int i=0;i<v;i++){
            if(vertexVisited[i]!=1&&min>weight[i]){
                min=weight[i];
                minV=i;
            }
        }
    return minV;
}
int FindParent(int* Parent,int v){
    if(Parent[v]==v){
        return v;
    }
    return FindParent(Parent,Parent[v]);
}
void PRIMS(struct ConnectionNode** arr,int v){
    int* weight=(int*)malloc(v*sizeof(int));
    int* vertexVisited=(int*)malloc(v*sizeof(int));
    for(int i=0;i<v;i++){
        vertexVisited[i]=0;
        weight[i]=2147483647;
    }
    weight[0]=0;
    int edges=0;
    while(edges<v-1){
        int indx=MinWeightVertex(weight,vertexVisited,v);
        struct ConnectionNode* tmp=arr[indx];
        vertexVisited[indx]=1;
        while(tmp!=NULL){
            if(weight[tmp->vertex]>tmp->EdgeWeight){
                if(vertexVisited[tmp->vertex]!=1){
                    weight[tmp->vertex]=tmp->EdgeWeight;
                }
            }
            tmp=tmp->next;
        }
        edges++;
    }
    int TotalPathCost=0;
    for(int i=0;i<v;i++){
        TotalPathCost=TotalPathCost+weight[i];
    }
    printf("%d\n",TotalPathCost);
    return;
}
void KRUSKALS(struct ConnectionNode** arr,int v){
    int* Parent=(int*)malloc(v*sizeof(int));
    for(int i=0;i<v;i++){
        Parent[i]=i;
    }
    int TotalPathCost=0;
    for(int Edges=0;Edges<v-1;Edges++){
        int MinEdgeWeight=2147483647;
        int v1=-1,v2=-1,i=0;
        while(i<v){
            struct ConnectionNode* tmp=arr[i];
            while(tmp!=NULL){
                if(MinEdgeWeight>tmp->EdgeWeight){
                    int p=FindParent(Parent,i);
                    int q=FindParent(Parent,tmp->vertex);
                    if(p!=q){
                        v1=i;
                        v2=tmp->vertex;
                        MinEdgeWeight=tmp->EdgeWeight;
                    }
                }
                tmp=tmp->next;
            }
            i++;
        }
        TotalPathCost=TotalPathCost+MinEdgeWeight;
        int p1=FindParent(Parent,v1);
        int p2=FindParent(Parent,v2);
        Parent[p1]=p2;
    }
    printf("%d\n",TotalPathCost);
    return;
}
int main(){
    char type;
    int vertexNum;
    scanf("%c",&type);
    scanf("%d",&vertexNum);
    struct ConnectionNode** AdjList=(struct ConnectionNode**)calloc(vertexNum,sizeof(struct ConnectionNode*));
    for(int i=0;i<vertexNum;i++){
        AdjList[i]=NULL;
    }
    InputAdjList(AdjList,vertexNum);
    if(type=='a'){
        KRUSKALS(AdjList,vertexNum);
    }else{
        PRIMS(AdjList,vertexNum);
    }
    return 0;
}
