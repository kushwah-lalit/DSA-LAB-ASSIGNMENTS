#include <stdio.h>
#include <stdlib.h>
struct Tnode{
    struct Tnode * left;
    struct Tnode * right;
    int Heightcurrent;
    int data;
};
struct AVL{
    struct Tnode * root;
};
struct Tnode* Createnode(int key){
    struct Tnode* Nnode=(struct Tnode*)calloc(1,sizeof(struct Tnode));
    Nnode->data=key;
    Nnode->Heightcurrent=0;
    Nnode->left=NULL;
    Nnode->right=NULL;
    return Nnode;
}
int MAX(int a,int b){
    if(a<b){
        return b;
    }
    return a;
}
struct Tnode* SHelper(struct Tnode* root,int k){
        if(root==NULL){
            return NULL;
        }
        if(root->data==k){
            return root;
        }
        if(root->data>k){
            struct Tnode* x=SHelper(root->left,k);
            return x;
        }
        if(root->data<k){
            struct Tnode* x=SHelper(root->right,k);
            return x;
        }
    return NULL;
}
int EvaluateHeight(struct Tnode* root){
    if(root==NULL){
        return 0;
    }
    int l=EvaluateHeight(root->left);
    int r=EvaluateHeight(root->right);
    return MAX(l,r)+1;
}
struct Tnode* SEARCH(struct AVL* A,int k){
    if(A->root==NULL){
        return NULL;
    }else{
        return SHelper(A->root,k);
    }
}
int GetBalance(struct Tnode* A,struct Tnode* k){
    if(k==NULL){
        return 0;
    }
    return EvaluateHeight(k->left)-EvaluateHeight(k->right);
}
void Print(struct Tnode* root){
    if(root==NULL){
        printf("( ) ");
        return;
    }
    printf("( ");
    printf("%d ",root->data);
    Print(root->left);
    Print(root->right);
    printf(") ");
    return;
}
void PRINTREE(struct AVL* A){
    Print(A->root);
    printf("\n");
    return;
}
int check(struct Tnode* K){
    if(K==NULL){
        return 1;
    }
    int diff=EvaluateHeight(K->left)-EvaluateHeight(K->right);
    if(diff<-1||diff>1){
        return 0;
    }
    if(check(K->left)&&check(K->right)){
        return 1;
    }
    return 0;
}
int IsAVL(struct AVL* A){
    return check(A->root);
}
struct Tnode* RightMIN(struct Tnode* root){
    if(root==NULL){
        return NULL;
    }
    if(root->left!=NULL){
        return RightMIN(root->left);
    }
    return root;
}
struct Tnode* LEFTROTATE(struct AVL* A,struct Tnode* k){
    struct Tnode* x=k->right;
    struct Tnode* y=x->left;
    x->left=k;
    k->right=y;
    k->Heightcurrent=MAX(EvaluateHeight(k->right),EvaluateHeight(k->left))+1;
    x->Heightcurrent=MAX(EvaluateHeight(x->right),EvaluateHeight(x->left))+1;
    return x;
}
struct Tnode* RIGHTROTATE(struct AVL* A,struct Tnode* k){
    struct Tnode* x=k->left;
    struct Tnode* y=x->right;
    x->right=k;
    k->left=y;
    k->Heightcurrent=MAX(EvaluateHeight(k->right),EvaluateHeight(k->left))+1;
    x->Heightcurrent=MAX(EvaluateHeight(x->right),EvaluateHeight(x->left))+1;
    return x;
}
struct Tnode* INSERT(struct Tnode* A,int k){
    if(A==NULL){
        struct Tnode* x=Createnode(k);
        return x;
    }
    int balance;
    if(A->data==k){
        return A;
    }else if(A->data>k){
        A->left=INSERT(A->left,k);
        A->Heightcurrent=MAX(EvaluateHeight(A->right),EvaluateHeight(A->left))+1;
        balance=EvaluateHeight(A->left)-EvaluateHeight(A->right);
        if(balance<0){
            balance=-balance;
        }
        if(balance>=2){
            if(A->left->data>k){
                A=RIGHTROTATE(NULL,A);
            }else{
                A->left=LEFTROTATE(NULL,A->left);
                A=RIGHTROTATE(NULL,A);
            }
        }
    }else{
        A->right=INSERT(A->right,k);
        A->Heightcurrent=MAX(EvaluateHeight(A->right),EvaluateHeight(A->left))+1;
        balance=EvaluateHeight(A->left)-EvaluateHeight(A->right);
        if(balance<0){
            balance=-balance;
        }
        if(balance>=2){
            if(A->right->data<k){
                A=LEFTROTATE(NULL,A);
            }else{
                A->right=RIGHTROTATE(NULL,A->right);
                A=LEFTROTATE(NULL,A);
            }
        }
    }
    return A;

}
struct Tnode* DELETE(struct Tnode* A,int k){
    if(A==NULL){
        return NULL;
    }
    int balance;
    if(A->data>k){
        A->left=DELETE(A->left,k);
    }else if(A->data<k){
        A->right=DELETE(A->right,k);
    }else{
        if(A->right==NULL&&A->left!=NULL){
            struct Tnode* x=A;
            A=A->left;
            x->left=NULL;
            free(x);
            return A;
        }else if(A->left==NULL&&A->right!=NULL){
            struct Tnode* x=A;
            A=A->right;
            x->right=NULL;
            free(x);
            return A;
        }else if(A->left==NULL&&A->right==NULL){
            struct Tnode* x=A;
            A=NULL;
            free(x);
            return NULL;
        }else{
            struct Tnode* K=RightMIN(A->right);
            A->data=K->data;
            A->right=DELETE(A->right,K->data);
        }
    }
    if(A==NULL){
        return A;
    }
    A->Heightcurrent=MAX(EvaluateHeight(A->right),EvaluateHeight(A->left))+1;
    balance=EvaluateHeight(A->left)-EvaluateHeight(A->right);
    if(balance>=2){
        if(GetBalance(A->left,A->left)>=0){
            return RIGHTROTATE(NULL,A);
        }
        if(GetBalance(A->left,A->left)<0){
            A->left=LEFTROTATE(NULL,A->left);
            return RIGHTROTATE(NULL,A);
        }
    }
    if(balance<=-2){
        if(GetBalance(A->right,A->right)<=0){
            return LEFTROTATE(NULL,A);
        }
        if(GetBalance(A->right,A->right)>0){
            A->right=RIGHTROTATE(NULL,A->right);
            return LEFTROTATE(NULL,A);
        }
    }
    return A;
}
int main(){
    struct AVL* A=(struct AVL*)calloc(1,sizeof(struct AVL));
    A->root=NULL;
    char c;
    scanf("%c",&c);
    while(c!='e'){
        if(c=='i'){
            int key;
            scanf("%d",&key);
            A->root=INSERT(A->root,key);
        }else if(c=='s'){
            int k;
            scanf("%d",&k);
            struct Tnode* x=SEARCH(A,k);
            if(x==NULL){
                printf("FALSE\n");
            }else{
                printf("TRUE\n");
            }
        }else if(c=='b'){
            int key;
            scanf("%d",&key);
            struct Tnode* x=SEARCH(A,key);
            if(x==NULL){
                printf("FALSE\n");
            }else{
                int k=GetBalance(A->root,x);
                printf("%d\n",k);
            }
        }else if(c=='p'){
            PRINTREE(A);
        }else if(c=='d'){
            int k;
            scanf("%d",&k);
            struct Tnode* x=SEARCH(A,k);
            if(x==NULL){
                printf("FALSE\n");
            }else{
                printf("%d\n",k);
                A->root=DELETE(A->root,k);
            }
        }
        scanf("%c",&c);
    }
    return 0;
}
