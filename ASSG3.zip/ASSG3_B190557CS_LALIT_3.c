#include <stdio.h>
#include <stdlib.h>
#include <string.h>
struct Tnode{
    struct Tnode * left;
    struct Tnode * right;
    int color;
    //0-red 1-black
    int data;
};
struct RBTREE{
    struct Tnode * root;
};
struct Tnode* Createnode(int key){
    struct Tnode* Nnode=(struct Tnode*)calloc(1,sizeof(struct Tnode));
    Nnode->data=key;
    Nnode->color=0;
    Nnode->left=NULL;
    Nnode->right=NULL;
    return Nnode;
}
void Print(struct Tnode* root){
    if(root==NULL){
        printf("( ) ");
        return;
    }
    printf("( ");
    printf("%d ",root->data);
    if(root->color==0){
        printf("R ");
    }else{
        printf("B ");
    }
    Print(root->left);
    Print(root->right);
    printf(") ");
    return;
}
void PRINTREE(struct RBTREE* A){
    Print(A->root);
    printf("\n");
    return;
}
struct Tnode* LEFTROTATE(struct RBTREE* A,struct Tnode* k){
    struct Tnode* x=k->right;
    struct Tnode* y=x->left;
    k->right=y;
    x->left=k;
    //swap color
    char colortemp=k->color;
    k->color=x->color;
    x->color=colortemp;
    return x;
}
struct Tnode* RIGHTROTATE(struct RBTREE* A,struct Tnode* k){
    struct Tnode* x=k->left;
    struct Tnode* y=x->right;
    k->left=y;
    x->right=k;
    //swap color
    char colortemp=k->color;
    k->color=x->color;
    x->color=colortemp;
    return x;

}
struct Tnode* INSERTREDBLACK(struct Tnode* root,int key){
    if(root==NULL){
        struct Tnode* x=Createnode(key);
        return x;
    }
    if(root->data>key){
        root->left=INSERTREDBLACK(root->left,key);
    }else{
        root->right=INSERTREDBLACK(root->right,key);
    }
    if(root->right!=NULL&&root->right->color==0){
        if(root->right->right!=NULL&&root->right->right->color==0){
            if(root->left!=NULL&&root->left->color==0){
                root->left->color=1;
                root->right->color=1;
                root->color=0;
                return root;
            }else{
                root=LEFTROTATE(NULL,root);
                return root;
            }
        }
        if(root->right->left!=NULL&&root->right->left->color==0){
            if(root->left!=NULL&&root->left->color==0){
                root->left->color=1;
                root->right->color=1;
                root->color=0;
                return root;
            }else{
                root->right=RIGHTROTATE(NULL,root->right);
                root=LEFTROTATE(NULL,root);
                return root;
            }
        }
    }
    if(root->left!=NULL&&root->left->color==0){
        if(root->left->left!=NULL&&root->left->left->color==0){
            if(root->right!=NULL&&root->right->color==0){
                root->left->color=1;
                root->right->color=1;
                root->color=0;
                return root;
            }else{
                root=RIGHTROTATE(NULL,root);
                return root;
            }
        }
        if(root->left->right!=NULL&&root->left->right->color==0){
            if(root->right!=NULL&&root->right->color==0){
                root->left->color=1;
                root->right->color=1;
                root->color=0;
                return root;
            }else{
                root->left=LEFTROTATE(NULL,root->left);
                root=RIGHTROTATE(NULL,root);
                return root;
            }
        }
    }
    return root;
}
int main(){
    struct RBTREE* A=(struct RBTREE*)calloc(1,sizeof(struct RBTREE));
    A->root=NULL;
    char x[100];
    scanf("%s",x);
    while(strcmp(x,"t")!=0){
        int num=0;
        for(int i=0;x[i]!='\0';i++){
            num=num*10+(x[i]-48);
        }
        A->root=INSERTREDBLACK(A->root,num);
        if(A->root->color!=1){
            A->root->color=1;
        }
        PRINTREE(A);
        scanf("%s",x);
    }
    return 0;
}

