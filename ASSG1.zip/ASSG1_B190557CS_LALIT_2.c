#include<stdio.h>
#include<stdlib.h>
#include<string.h>
struct Treenode{
    int data;
    struct Treenode* parent;
    struct Treenode* right;
    struct Treenode* left;
};
struct BT{
    struct Treenode* ROOT;
};
struct Treenode* SEARCH(struct Treenode* node,int k){
    if(node==NULL){
        return NULL;
    }
    if(node->data==k){
        return node;
    }
    struct Treenode* x=SEARCH(node->right,k);
    if(x==NULL){
        x=SEARCH(node->left,k);
    }
    return x;
}
struct Treenode* CREATE_NODE(int k){
    struct Treenode* node=(struct Treenode*)calloc(1,sizeof(struct Treenode));
    node->data=k;
    node->left=NULL;
    node->right=NULL;
    node->parent=NULL;
    return node;
}
int FindTreeEnd(int s,int e,char arr[]){
    if (s>e){
        return -1;
    }
    int total=0;
    for(int i=s;i<=e;i++){
       if(arr[i]== '('){
            total=total+1;
        }else if(arr[i]==')'){
            total=total-1;
            if(total==0){
                return i;
            }
        }
    }
    return -1;
}
struct Treenode* BUILD(int s,int e,char arr[]){
    if(s>e||arr[s+2]==')'){
        return NULL;
    }
    int K=0,indx=-1,NumEndIndx=-1;
    for(int i=s+2;arr[i]!=' ';i++){
        K=K*10+(arr[i]-48);
        NumEndIndx=i;
    }
    struct Treenode* root=CREATE_NODE(K);
    if (NumEndIndx+2<=e&&arr[NumEndIndx+2] =='('){
        indx=FindTreeEnd(NumEndIndx+2,e,arr);
    }
    if(indx!=-1){
        root->left=BUILD(NumEndIndx+2,indx,arr);
        root->right=BUILD(indx+2,e-1,arr);
        if(root->left!=NULL){
            root->left->parent=root;
        }
        if(root->right!=NULL){
            root->right->parent=root;
        }
    }
    return root;
}
void PrintAtDepth(int *check,struct Treenode *node,struct Treenode* root,int depth){
    if(root==NULL){
        return;
    }
    if(depth<2){
        return;
    }else if(depth==2){
        if(root->left==node||root->right==node){
            return;
        }
        if(root->left!=NULL){
            printf("%d ",root->left->data);
            (*check)++;
        }
        if(root->right!=NULL){
            printf("%d ",root->right->data);
            (*check)++;
        }
    }else{
        PrintAtDepth(check,node,root->left,depth-1);
        PrintAtDepth(check,node,root->right,depth-1);
    }
}
int FindDepth(int depth,struct Treenode *root,struct Treenode *node){
    if (root== NULL){
        return -1;
    }
    if (root==node){
        return depth;
    }
    int k=FindDepth(depth+1,root->left,node);
    if(k!=-1){
        return k;
    }
    return FindDepth(depth+1,root->right,node);
}
void PrintCousins(int* check,struct Treenode *root,int k){
    struct Treenode* x=SEARCH(root,k);
    int depth=FindDepth(1,root,x);
    PrintAtDepth(check,x,root,depth);
}
int main(){
    char arr[1000000];
    scanf("%[^\n]%*c",arr);
    int k;
    scanf("%d",&k);
    int n=(int)strlen(arr);
    struct Treenode* Root=BUILD(0,n-1,arr);
    int check=0;
    PrintCousins(&check,Root,k);
    if(check==0){
        printf("-1\n");
    }else{
        printf("\n");
    }
    return 0;
}
