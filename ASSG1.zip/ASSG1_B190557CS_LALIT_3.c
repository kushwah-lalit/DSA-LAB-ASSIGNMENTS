#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#define MAX(n1,n2,n3) ((n1>n2)?(n1>n3?n1:n3):(n2>n3?n2:n3))
#define MIN(n1,n2,n3) (n3<(n1<n2?n1:n2)?n3:((n1<n2)?n1:n2))
struct info_node{
    int checkbst;
    int sumofsubT;
    int rightminofsubT;
    int leftmaxofsubT;
    int count;
};
struct Treenode{
    int data;
    struct Treenode* parent;
    struct Treenode* right;
    struct Treenode* left;
};
struct BT{
    struct Treenode* ROOT;
};
struct Treenode* CREATE_NODE(int k){
    struct Treenode* node=(struct Treenode*)calloc(1,sizeof(struct Treenode));
    node->data=k;
    node->left=NULL;
    node->right=NULL;
    node->parent=NULL;
    return node;
}
int FindTreeEnd(int s,int e,char arr[]){
    if (s>e){
        return -1;
    }
    int total=0;
    for(int i=s;i<=e;i++){
       if(arr[i]== '('){
            total=total+1;
        }else if(arr[i]==')'){
            total=total-1;
            if(total==0){
                return i;
            }
        }
    }
    return -1;
}
struct Treenode* BUILD(int s,int e,char arr[]){
    if(s>e||arr[s+2]==')'){
        return NULL;
    }
    int K=0,indx=-1,NumEndIndx=-1;
    for(int i=s+2;arr[i]!=' ';i++){
        K=K*10+(arr[i]-48);
        NumEndIndx=i;
    }
    struct Treenode* root=CREATE_NODE(K);
    if (NumEndIndx+2<=e&&arr[NumEndIndx+2] =='('){
        indx=FindTreeEnd(NumEndIndx+2,e,arr);
    }
    if(indx!=-1){
        root->left=BUILD(NumEndIndx+2,indx,arr);
        root->right=BUILD(indx+2,e-1,arr);
        if(root->left!=NULL){
            root->left->parent=root;
        }
        if(root->right!=NULL){
            root->right->parent=root;
        }
    }
    return root;
}
struct info_node* Evaluate(int k,struct Treenode* Root) {
    if(Root==NULL){
        struct info_node* I=(struct info_node*)calloc(1,sizeof(struct info_node));
        I->checkbst=1;
        I->sumofsubT=0;
        I->rightminofsubT=2147483647;
        I->leftmaxofsubT=-2147483648;
        I->count=0;
        return I;
    }
    struct info_node* L_Ans=Evaluate(k,Root->left);
    struct info_node* R_Ans=Evaluate(k,Root->right);
    int check=(L_Ans->checkbst)&&(L_Ans->checkbst)&&(Root->data>L_Ans->leftmaxofsubT)&&(Root->data<=R_Ans->rightminofsubT);
    int currentsum=L_Ans->sumofsubT+R_Ans->sumofsubT+Root->data;
    struct info_node* I=(struct info_node*)calloc(1,sizeof(struct info_node));
    if(currentsum==k&&check==1){
        I->count=1+L_Ans->count+R_Ans->count;
    }else{
        I->count=L_Ans->count+R_Ans->count;
    }
    int Lmax=MAX(Root->data,L_Ans->leftmaxofsubT,R_Ans->leftmaxofsubT);
    int RMin=MIN(Root->data,L_Ans->rightminofsubT,R_Ans->rightminofsubT);
    I->checkbst=check;
    I->sumofsubT=currentsum;
    I->leftmaxofsubT=Lmax;
    I->rightminofsubT=RMin;
    return I;
}
int main(){
    char arr[1000000];
    scanf("%[^\n]%*c",arr);
    int k;
    scanf("%d",&k);
    int n=(int)strlen(arr);
    struct Treenode* Root=BUILD(0,n-1,arr);
    struct info_node* ans=Evaluate(k,Root);
    if(ans->count!=0){
        printf("%d\n",ans->count);
    }else{
        printf("-1\n");
    }
    return 0;
}
