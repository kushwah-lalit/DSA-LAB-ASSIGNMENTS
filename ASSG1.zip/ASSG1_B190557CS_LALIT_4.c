#include<stdio.h>
#include<stdlib.h>
struct Treenode{
    int data;
    struct Treenode* p;
    struct Treenode* right;
    struct Treenode* left;
};
struct BST{
    struct Treenode* ROOT;
};
struct Treenode* CREATENODE(int k){
    struct Treenode* node=(struct Treenode*)calloc(1,sizeof(struct Treenode));
    node->data=k;
    node->left=NULL;
    node->right=NULL;
    node->p=NULL;
    return node;
}
struct Treenode* SEARCH(struct BST* T,int k){
    struct Treenode* root=T->ROOT;
    if(root==NULL){
        return NULL;
    }
    while(root!=NULL){
        if(root->data==k){
            return root;
        }else if(root->data<k){
            root=root->right;
        }else{
            root=root->left;
        }
    }
    return NULL;
}
int MAXVALUE(struct BST* T){
    struct Treenode* Root=T->ROOT;
    while(Root->right!=NULL){
        Root=Root->right;
    }
    return Root->data;
}

int MINVALUE(struct BST* T){
    struct Treenode* Root=T->ROOT;
    while(Root->left!=NULL){
        Root=Root->left;
    }
    return Root->data;
}
void INSERT(struct BST* T,struct Treenode* x){
    struct Treenode* pre=NULL;
    struct Treenode* root=T->ROOT;
    while(root!=NULL){
        pre=root;
        if(x->data>root->data){
            root=root->right;
        }else{
            root=root->left;
        }
    }
    x->p=pre;
    if(pre==NULL){
        T->ROOT=x;
    }else{
        if(x->data>pre->data){
            pre->right=x;
        }else{
            pre->left=x;
        }
    }
    return;
}
struct Treenode* MinNode(struct Treenode* Root){
    while(Root->left!=NULL){
        Root=Root->left;
    }
    return Root;
}
struct Treenode* MaxNode(struct Treenode* Root){
    while(Root->right!=NULL){
        Root=Root->right;
    }
    return Root;
}

int FindDepth(int depth,struct Treenode *root,struct Treenode *node){
    if (root== NULL){
        return -1;
    }
    if (root==node){
        return depth;
    }
    int k=FindDepth(depth+1,root->left,node);
    if(k!=-1){
        return k;
    }
    return FindDepth(depth+1,root->right,node);
}
int LEVEL(struct BST *T,int k){
    struct Treenode* root=T->ROOT;
    struct Treenode* node=SEARCH(T,k);
    if(node==NULL){
        return -1;
    }
    if(root==NULL){
        return -1;
    }
    return FindDepth(1,root,node);
}
struct Treenode* SUCCESSOR(struct BST* T,int y){
    struct Treenode* Y=SEARCH(T,y);
    if(Y==NULL){
        return NULL;
    }else if(Y->right!=NULL){
        return MinNode(Y->right);
    }
    struct Treenode* Final=Y->p;
    while(Final!=NULL&&Y==Final->right){
        Y=Final;
        Final=Final->p;
    }
    return Final;
}
struct Treenode* PREDECESSOR(struct BST* T,int y){
    struct Treenode* Y=SEARCH(T,y);
    if(Y==NULL){
        return NULL;
    }else if(Y->left!=NULL){
        return MaxNode(Y->left);
    }
    struct Treenode* Final=Y->p;
    while(Final!=NULL&&Y==Final->left){
        Y=Final;
        Final=Final->p;
    }
    return Final;
}
void TRANSPLANT(struct BST* T,struct Treenode* u,struct Treenode* v){
    if(u->p==NULL){
        T->ROOT=v;
    }else if(u==u->p->left){
        u->p->left=v;
    }else{
        u->p->right=v;
    }
    if(v!=NULL){
        v->p=u->p;
    }
}
void DELETE(struct BST* T,struct Treenode* x){
    if(x==NULL){
        printf("-1\n");
        return;
    }else{
        printf("%d\n",x->data);
    }
    if(x->left==NULL){
      TRANSPLANT(T,x,x->right);
    }else if(x->right==NULL){
       TRANSPLANT(T,x,x->left);
    }else{
        struct Treenode* k=MinNode(x->right);
        if(k->p!=x){
            TRANSPLANT(T,k,k->right);
            k->right=x->right;
            k->right->p=k;
        }
            TRANSPLANT(T,x,k);
            k->left=x->left;
            k->left->p=k;
    }
    x->p=NULL;
    x->left=NULL;
    x->right=NULL;
    free(x);
    return;
}
void INORDERHELPER(struct Treenode* T){
    if(T==NULL){
        return;
    }else{
        INORDERHELPER(T->left);
        printf("%d ",T->data);
        INORDERHELPER(T->right);
    }
}
void INORDER(struct BST* T){
    INORDERHELPER(T->ROOT);
    printf("\n");
    return;
}
void PREORDERHELPER(struct Treenode* T){
    if(T==NULL){
        return;
    }else{
        printf("%d ",T->data);
        PREORDERHELPER(T->left);
        PREORDERHELPER(T->right);
    }
}
void PREORDER(struct BST* T){
    PREORDERHELPER(T->ROOT);
    printf("\n");
    return;
}
void POSTORDERHELPER(struct Treenode* T){
    if(T==NULL){
        return;
    }else{
        POSTORDERHELPER(T->left);
        POSTORDERHELPER(T->right);
        printf("%d ",T->data);
    }
}
void POSTORDER(struct BST* T){
    POSTORDERHELPER(T->ROOT);
    printf("\n");
    return;
}

int main(){
    struct BST* T=(struct BST*)malloc(1*sizeof(struct BST));
    T->ROOT=NULL;
    char c;
    scanf("%c",&c);
    while(c!='e'){
        if(c=='a'){
            int k;
            scanf("%d",&k);
            struct Treenode* x=CREATENODE(k);
            INSERT(T,x);
        }else if(c=='d'){
            int k;
            scanf("%d",&k);
            struct Treenode* x=SEARCH(T,k);
            DELETE(T,x);
        }else if(c=='s'){
            int k;
            scanf("%d",&k);
            struct Treenode* x=SEARCH(T,k);
            if(x!=NULL){
                printf("1\n");
            }else{
                printf("-1\n");
            }
        }else if(c=='l'){
            int k;
            scanf("%d",&k);
            int x=LEVEL(T,k);
            printf("%d\n",x);
        }else if(c=='m'){
            printf("%d\n",MINVALUE(T));
        }else if(c=='x'){
            printf("%d\n",MAXVALUE(T));
        }else if(c=='r'){
            int k;
            scanf("%d",&k);
            struct Treenode* x=PREDECESSOR(T,k);
            if(x!=NULL){
                printf("%d\n",x->data);
            }else{
                printf("-1\n");
            }
        }else if(c=='u'){
            int k;
            scanf("%d",&k);
            struct Treenode* x=SUCCESSOR(T,k);
            if(x!=NULL){
                printf("%d\n",x->data);
            }else{
                printf("-1\n");
            }
        }else if(c=='i'){
            INORDER(T);
        }else if(c=='p'){
            PREORDER(T);
        }else if(c=='t'){
            POSTORDER(T);
        }
        scanf("%c",&c);
    }
    return 0;
}


