#include<stdio.h>
#include<stdlib.h>
#include<string.h>
struct Treenode{
    int data;
    struct Treenode* parent;
    struct Treenode* right;
    struct Treenode* left;
};
struct BT{
    struct Treenode* ROOT;
};
struct Treenode* CREATE_NODE(int k){
    struct Treenode* node=(struct Treenode*)calloc(1,sizeof(struct Treenode));
    node->data=k;
    node->left=NULL;
    node->right=NULL;
    node->parent=NULL;
    return node;
}
int FindTreeEnd(int s,int e,char arr[]){
    if (s>e){
        return -1;
    }
    int total=0;
    for(int i=s;i<=e;i++){
       if(arr[i]== '('){
            total=total+1;
        }else if(arr[i]==')'){
            total=total-1;
            if(total==0){
                return i;
            }
        }
    }
    return -1;
}
struct Treenode* BUILD(int s,int e,char arr[]){
    if(s>e||arr[s+2]==')'){
        return NULL;
    }
    int K=0,indx=-1,NumEndIndx=-1;
    for(int i=s+2;arr[i]!=' ';i++){
        K=K*10+(arr[i]-48);
        NumEndIndx=i;
    }
    struct Treenode* root=CREATE_NODE(K);
    if (NumEndIndx+2<=e&&arr[NumEndIndx+2] =='('){
        indx=FindTreeEnd(NumEndIndx+2,e,arr);
    }
    if(indx!=-1){
        root->left=BUILD(NumEndIndx+2,indx,arr);
        root->right=BUILD(indx+2,e-1,arr);
        if(root->left!=NULL){
            root->left->parent=root;
        }
        if(root->right!=NULL){
            root->right->parent=root;
        }
    }
    return root;
}
struct Treenode* KSMALLHELPER(struct Treenode* root,int* k){
    if (root == NULL){
        return NULL;
    }
    struct Treenode* l=KSMALLHELPER(root->left,k);
    if(l!=NULL){
        return l;
    }
    (*k)=(*k)-1;
    if((*k)==0){
        return root;
    }
    return KSMALLHELPER(root->right,k);
}
int KSMALLEST(struct Treenode* Root,int kth){
    return KSMALLHELPER(Root,&kth)->data;
}
int main(){
    char arr[1000000];
    scanf("%[^\n]%*c",arr);
    int kth;
    scanf("%d",&kth);
    int n=(int)strlen(arr);
    struct Treenode* Root=BUILD(0,n-1,arr);
    printf("%d\n",KSMALLEST(Root,kth));
    return 0;
}
