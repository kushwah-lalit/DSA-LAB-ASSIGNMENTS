#include<stdio.h>
#include<stdlib.h>
struct Qnode{
    struct Treenode* data;
    struct Qnode* next;
};
struct QUEUE{
    struct Qnode* head;
    struct Qnode* tail;
};
struct Treenode{
    int key;
    struct Treenode* p;
    struct Treenode* right;
    struct Treenode* left;
};
struct BT{
    struct Treenode* ROOT;
};
struct Qnode* CREATE_NODE(struct Treenode* key){
     struct Qnode* x=(struct Qnode*)calloc(1,sizeof(struct Qnode));
     x->data=key;
     x->next=NULL;
     return x;
}
struct Treenode* CREATENODE(int k){
    struct Treenode* K=(struct Treenode*)calloc(1,sizeof(struct Treenode));
    K->key=k;
    K->left=NULL;
    K->right=NULL;
    K->p=NULL;
    return K;
}
void helper(struct Treenode* head){
    if(head==NULL){
        printf("( ) ");
        return;
    }
    printf("( ");
    printf("%d ",head->key);
    helper(head->left);
    helper(head->right);
    printf(") ");
    return;
}
void PRINT(struct BT* T){
    struct Treenode* root=T->ROOT;
    helper(root);
    return;
}
void Enqueue(struct QUEUE* Q,struct Treenode* x){
    struct Qnode* X=CREATE_NODE(x);
    if(Q->head==NULL){
        Q->head=X;
        Q->tail=X;
    }else{
        Q->tail->next=X;
        Q->tail=X;
    }
    return;
}
void Dequeue(struct QUEUE* Q){
    if(Q->head==NULL) {
        return;
    }
    struct Qnode *x=Q->head;
    Q->head=Q->head->next;
    x->next=NULL;
    free(x);
    return;
}
struct QUEUE* BuildQueue(){
    struct QUEUE* Q=(struct QUEUE*)calloc(1,sizeof(struct QUEUE));
    Q->head=NULL;
    Q->tail=NULL;
    return Q;
}
void INSERT(struct BT* T,int k){
    struct Treenode* Nnode=CREATENODE(k);
    if(T->ROOT==NULL){
        T->ROOT=Nnode;
        return;
    }
    struct QUEUE* Q=BuildQueue();
    Enqueue(Q,T->ROOT);
    while(Q->head!=NULL){
        struct Treenode* temp=Q->head->data;
        Dequeue(Q);
        if(temp->left==NULL){
            temp->left=Nnode;
            Nnode->p=temp;
            return;
        }else{
            Enqueue(Q,temp->left);
        }
        if(temp->right==NULL){
            temp->right=Nnode;
            Nnode->p=temp;
            return;
        }else{
            Enqueue(Q,temp->right);
        }
    }
}
int main(){
    struct BT* T=(struct BT*)malloc(1*sizeof(struct BT));
    char x;
    scanf("%c",&x);
    while(x!='e'){
        if(x=='i'){
            int k;
            scanf("%d",&k);
            INSERT(T,k);
        }else if(x=='p'){
            PRINT(T);
            printf("\n");
        }
        scanf("%c",&x);
    }
    return 0;
}

